﻿using System.Text.Json;
using System;
using System.Text.Json;
using System.Net.Http;
using ApiProject.Controllers;
using Google.Apis.Sheets.v4.Data;


namespace ApiProject.Model


{

    public class SheetModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Price { get; set; }
    }


}