﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ApiProject.Class;
using System.Drawing.Text;
using Google.Apis.Sheets.v4.Data;
using Newtonsoft.Json.Linq;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System;
using System.Text.Json;
using System.Net.Http;
using ApiProject.Model;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Data;
using Amazon.CognitoSync.Model;
using Bogus;

namespace ApiProject.Controllers
    
{

    [ApiController]
    [Route("[controller]")]
    public class SheetController : ControllerBase
    {

       


        private readonly GoogleSheetsService _sheetsService;

        public SheetController(GoogleSheetsService sheetsService)
        {
          
            _sheetsService = sheetsService;

        }

        [HttpGet]
        public async Task<IActionResult> GetSheetData()
        {


            string spreadsheetId = "1bG_fRAX0O_X8Uz2b6tuT503RjH2YMM3jHb__oYXVYjQ";
            string range = "TestSheet";

          
            var data = await _sheetsService.GetSheetDataAsync(spreadsheetId, range);


         

            var sheetdata = new List<SheetModel> ();
  

            if (data != null && data.Count > 0)
            {
                
                

                foreach (var row in data.Skip(1))
                {
                    
                    var cnvart = new SheetModel()
                    {
                        Id = int.Parse((string)row[0]),                     
                        Name = (string)row[1],
                        Price = (string)row[2]
                    };
                    sheetdata.Add(cnvart);

                }
                

            }
            return Ok(sheetdata);

          

        }
    }
}