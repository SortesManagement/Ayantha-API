﻿﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using System.IO;

namespace ApiProject.Class
{
    public interface IGoogleSheetsService
    {
        Task<List<List<object>>> GetSheetDataAsync(string spreadsheetId, string sheetName);
    }

    public class GoogleSheetsService 
    {
        private readonly SheetsService _sheetsService;

        public GoogleSheetsService()
        {
            _sheetsService = InitializeService();

        }

        private SheetsService InitializeService()
        {
            GoogleCredential credential;
            using (var stream = new FileStream("D:\\Intern\\APIProject\\APIProject\\JsonFile\\newapi-434710-d98c14ffd767.json", FileMode.Open, FileAccess.Read))
            {
                credential = GoogleCredential.FromStream(stream)
                             .CreateScoped(SheetsService.Scope.SpreadsheetsReadonly);
            }

            return new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = "TestSheet",
            });
        }

        public async Task<IList<IList<object>>> GetSheetDataAsync(string spreadsheetId, string range)
        {
            var request = _sheetsService.Spreadsheets.Values.Get(spreadsheetId, range);
            var response = await request.ExecuteAsync();
            return response.Values;
        }
        
    }
}